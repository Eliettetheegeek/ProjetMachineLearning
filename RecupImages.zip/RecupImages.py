﻿from icrawler.builtin import GoogleImageCrawler
from PIL import Image
import os
import time
# -------------------------------
# CONFIGURATION
# -------------------------------
dataset_dir = "dataset_amphibiens"
classes = dict(
    grenouille=["rainette photo",
                "rainette ibérique photo",
                "rainette sarde photo",
                "grenouille verte photo",
                "rainette méridionale photo",
                "grenouille taureau photo",
                "grenouille rousse photo",
                "grenouille des Pyrénées photo",
                "grenouille agile photo"],

    crapaud=["crapaud photo",
             "toad photo",
             "crapaud américain photo",
             "crapaud brun photo",
             "crapaud vert photo"
             "crapaud accoucheur",
             "crapaud de Fowler photo"
             "crapauducs photo"],
    têtard=["têtard photo",
            "tadpole photo",
            "têtard dans l'eau photo",
            "têtard grenouille photo",
            "têtard tropical photo"
            "têtard crapaud photo"])
nb_images = 100  # nombre d’images par mot-clé
min_size = 200   # taille minimale (pixels) pour garder une image
# -------------------------------


def telecharger_images():
    """Télécharge les images Google Images pour chaque classe et mot-clé."""
    os.makedirs(dataset_dir, exist_ok=True)

    for label, keywords in classes.items():
        save_dir = os.path.join(dataset_dir, label)
        os.makedirs(save_dir, exist_ok=True)

        for keyword in keywords:
            print(f"Téléchargement de '{keyword}' pour la classe: {label}")
            crawler = GoogleImageCrawler(storage={"root_dir": save_dir})
            crawler.crawl(keyword=keyword, max_num=nb_images)


def nettoyer_dossier(path, min_size=200):
    """Supprime les icônes, images trop petites et fichiers corrompus."""
    for f in os.listdir(path):
        file_path = os.path.join(path, f)
        should_delete = False
        try:
            with Image.open(file_path) as img:
                #Supprimer si trop petit
                if img.width < min_size or img.height < min_size:
                    should_delete = True
                #Supprimr PNG avec transparence (souvent icone)
                elif img.mode in ("RGBA", "LA") or (file_path.endswith(".png") and "A" in img.getbands()):
                    should_delete = True
            #L'image est fermée , on peut la supprimer
            if should_delete:
                time.sleep(0.01) #Petit délai pour Windows
                os.remove(file_path)
        except Exception as e :
            #Supprimer si image corrompue ou illisisble
            try:
                time.sleep(0.01)
                os.remove(file_path)
            except PermissionError:
                print(f"⚠️ Impossible de supprimer {file_path} : fichier verrouillé")
            except Exception as ex:
                print(f"⚠️ Erreur lors de la suppression de {file_path} : {ex}")



def nettoyer_tout():
    """Nettoie toutes les classes du dataset."""
    for label in classes.keys():
        print(f"Nettoyage de la classe: {label}")
        save_dir = os.path.join(dataset_dir, label)
        nettoyer_dossier(save_dir, min_size=min_size)


if __name__ == "__main__":
    telecharger_images()
    nettoyer_tout()
    print("✅ Téléchargement et nettoyage terminés !")